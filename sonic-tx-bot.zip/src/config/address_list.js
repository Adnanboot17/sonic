export const addressList = [
  undefined, //leave it undefined, it will be used as param to send to your own address
  //   "ANOTHER ADDRESS",
];
